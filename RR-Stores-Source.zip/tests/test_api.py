from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from api.app import main
from api.app.database import Base, get_db
from api.app.models import Notification, Product, StoreUser
from api.app import notifications as notification_service


@pytest.fixture
def client(monkeypatch):
    test_engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    test_sessions = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)
    monkeypatch.setattr(main, "engine", test_engine)
    monkeypatch.setattr(main, "SessionLocal", test_sessions)
    monkeypatch.setenv("APP_ENV", "development")
    monkeypatch.delenv("STRIPE_SECRET_KEY", raising=False)

    def override_get_db():
        with test_sessions() as session:
            yield session

    main.app.dependency_overrides[get_db] = override_get_db
    with TestClient(main.app) as test_client:
        with test_sessions() as db:
            db.add(Product(
                name="Test journal",
                description="A test item",
                price=Decimal("12.50"),
                stock=3,
                category="Paper",
                image_url="https://example.com/journal.jpg",
                popularity=10,
                active=True,
            ))
            db.commit()
        yield test_client
    main.app.dependency_overrides.clear()
    test_engine.dispose()


def register(client, email="buyer@example.com"):
    response = client.post("/auth/register", json={"name": "Test Buyer", "email": email, "password": "correct-horse-123"})
    assert response.status_code == 201
    return response.json()["access_token"]


def checkout_details(payment_method="online"):
    return {
        "payment_method": payment_method,
        "delivery_name": "Test Buyer",
        "delivery_phone": "+919876543210",
        "address_line": "12 Market Road",
        "city": "Chennai",
        "state": "Tamil Nadu",
        "postal_code": "600001",
    }


def test_register_login_and_protected_cart(client):
    assert client.get("/cart").status_code == 401
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}
    assert client.get("/auth/me", headers=headers).json()["email"] == "buyer@example.com"
    assert client.post("/auth/login", json={"email": "buyer@example.com", "password": "wrong-password"}).status_code == 401
    assert client.get("/cart", headers=headers).json() == {"items": [], "total": 0.0}


def test_stock_checked_cart_and_demo_checkout(client):
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}
    added = client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 2})
    assert added.status_code == 200
    assert added.json()["total"] == 25.0
    assert client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 2}).status_code == 409

    checkout = client.post("/orders/checkout", headers=headers, json=checkout_details())
    assert checkout.status_code == 201
    assert checkout.json()["demo"] is True
    assert checkout.json()["payment_status"] == "pending"
    assert "free of cost" in checkout.json()["qr_text"]
    assert client.get("/cart", headers=headers).json()["items"] == []
    confirmed = client.post(f"/orders/{checkout.json()['order_id']}/confirm-demo-payment", headers=headers)
    assert confirmed.status_code == 200
    assert confirmed.json()["payment_status"] == "paid"
    order = client.get("/orders", headers=headers).json()[0]
    assert order["total"] == 25.0
    assert order["order_status"] == "confirmed"
    assert order["payment_method"] == "demo_qr"
    assert client.get("/notifications", headers=headers).json()[0]["type"] == "order_confirmed"


def test_catalog_filters_and_user_isolation(client):
    buyer_token = register(client, "buyer@example.com")
    other_token = register(client, "other@example.com")
    buyer_headers = {"Authorization": f"Bearer {buyer_token}"}
    other_headers = {"Authorization": f"Bearer {other_token}"}
    assert len(client.get("/products?category=Paper&max_price=20").json()) == 1
    client.post("/cart/items", headers=buyer_headers, json={"product_id": 1, "quantity": 1})
    assert client.get("/cart", headers=other_headers).json()["items"] == []


def test_stripe_checkout_uses_inr_and_clears_cart(client, monkeypatch):
    requests = []

    class FakeSession:
        @staticmethod
        def create(**payload):
            requests.append(payload)
            return SimpleNamespace(id="cs_test_123", url="https://stripe.example/checkout")

    class FakeStripe:
        api_key = None
        StripeError = RuntimeError
        checkout = SimpleNamespace(Session=FakeSession)

    monkeypatch.setattr(main, "stripe", FakeStripe)
    monkeypatch.setenv("STRIPE_SECRET_KEY", "sk_test_example")
    monkeypatch.delenv("STRIPE_CURRENCY", raising=False)
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}
    client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 1})

    checkout = client.post("/orders/checkout", headers=headers, json=checkout_details())

    assert checkout.status_code == 201
    assert checkout.json()["checkout_url"] == "https://stripe.example/checkout"
    assert requests[0]["line_items"][0]["price_data"]["currency"] == "inr"
    assert requests[0]["line_items"][0]["price_data"]["unit_amount"] == 1250
    assert client.get("/cart", headers=headers).json()["items"] == []


def test_cash_on_delivery_saves_address_and_keeps_payment_pending(client):
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}
    client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 1})

    checkout = client.post(
        "/orders/checkout",
        headers=headers,
        json=checkout_details("cod"),
    )

    assert checkout.status_code == 201
    assert checkout.json()["payment_method"] == "cod"
    assert checkout.json()["order_status"] == "confirmed"
    assert checkout.json()["payment_status"] == "pending"
    order = client.get(f"/orders/{checkout.json()['order_id']}", headers=headers).json()
    assert order["address_line"] == "12 Market Road"
    assert order["city"] == "Chennai"
    assert order["postal_code"] == "600001"
    assert order["payment_method"] == "cod"
    assert "cash on delivery" in client.get("/notifications", headers=headers).json()[0]["message"]


def test_websocket_delivers_cart_and_cross_process_notifications(client, monkeypatch):
    monkeypatch.setattr(main, "NOTIFICATION_POLL_INTERVAL", 0.05)
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}

    with client.websocket_connect(f"/ws?token={token}") as websocket:
        client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 1})
        assert websocket.receive_json()["type"] == "cart_updated"
        with main.SessionLocal() as db:
            db.add(Notification(user_id=1, type="shipping_update", message="Order shipped"))
            db.commit()
        assert websocket.receive_json()["message"] == "Order shipped"


def test_stripe_webhooks_confirm_and_fail_orders(client, monkeypatch):
    sessions = []

    class FakeSession:
        @staticmethod
        def create(**payload):
            sessions.append(payload)
            return SimpleNamespace(id=f"cs_test_{len(sessions)}", url="https://stripe.example/checkout")

    class FakeWebhook:
        event = None

        @classmethod
        def construct_event(cls, body, signature, secret):
            assert body == b"{}"
            assert signature == "test-signature"
            assert secret == "whsec_test"
            return cls.event

    class FakeStripe:
        api_key = None
        StripeError = RuntimeError
        SignatureVerificationError = ValueError
        checkout = SimpleNamespace(Session=FakeSession)
        Webhook = FakeWebhook

    monkeypatch.setattr(main, "stripe", FakeStripe)
    monkeypatch.setenv("STRIPE_SECRET_KEY", "sk_test_example")
    monkeypatch.setenv("STRIPE_WEBHOOK_SECRET", "whsec_test")
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}

    for expected_event in ("checkout.session.completed", "checkout.session.expired"):
        client.post("/cart/items", headers=headers, json={"product_id": 1, "quantity": 1})
        checkout = client.post("/orders/checkout", headers=headers, json=checkout_details())
        assert checkout.status_code == 201
        order_id = checkout.json()["order_id"]
        FakeWebhook.event = {
            "type": expected_event,
            "data": {"object": {
                "id": f"cs_test_{len(sessions)}",
                "metadata": {"order_id": str(order_id), "user_id": "1"},
                "payment_status": "paid" if expected_event.endswith("completed") else "unpaid",
            }},
        }
        webhook = client.post(
            "/payments/stripe/webhook",
            content=b"{}",
            headers={"stripe-signature": "test-signature"},
        )
        assert webhook.status_code == 200
        order = client.get(f"/orders/{order_id}", headers=headers).json()
        if expected_event.endswith("completed"):
            assert order["payment_status"] == "paid"
            assert order["order_status"] == "confirmed"
        else:
            assert order["payment_status"] == "failed"
            assert order["order_status"] == "cancelled"

    messages = client.get("/notifications", headers=headers).json()
    assert {message["type"] for message in messages} >= {"order_confirmed", "payment_failed"}


def test_configured_smtp_sends_order_email(monkeypatch):
    captured = []

    class FakeSMTP:
        def __init__(self, host, port, timeout):
            assert host == "smtp.example.test"
            assert port == 587
            assert timeout == 10

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def starttls(self):
            pass

        def login(self, username, password):
            assert username == "mailer"
            assert password == "smtp-test-password"

        def send_message(self, message):
            captured.append(message)

    monkeypatch.setattr(notification_service.smtplib, "SMTP", FakeSMTP)
    monkeypatch.setenv("SMTP_HOST", "smtp.example.test")
    monkeypatch.setenv("SMTP_PORT", "587")
    monkeypatch.setenv("SMTP_USER", "mailer")
    monkeypatch.setenv("SMTP_PASSWORD", "smtp-test-password")
    monkeypatch.setenv("EMAIL_FROM", "orders@example.test")

    notification_service.send_email("buyer@example.test", "Your order is confirmed")

    assert len(captured) == 1
    assert captured[0]["To"] == "buyer@example.test"
    assert captured[0]["Subject"] == "Order update from RR Stores"


def test_staff_upload_role_gate(client):
    token = register(client)
    headers = {"Authorization": f"Bearer {token}"}
    image = {"image": ("tiny.png", b"small-test-image", "image/png")}
    denied = client.post("/staff/products/1/image", headers=headers, files=image)
    assert denied.status_code == 403

    with main.SessionLocal() as db:
        user = db.scalar(select(StoreUser).where(StoreUser.email == "buyer@example.com"))
        user.role = "staff"
        db.commit()

    uploaded = client.post("/staff/products/1/image", headers=headers, files=image)
    assert uploaded.status_code == 200
    filename = Path(uploaded.json()["image_url"]).name
    (main.PRODUCT_MEDIA_DIR / filename).unlink(missing_ok=True)