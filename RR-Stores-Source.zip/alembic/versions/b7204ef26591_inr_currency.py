"""Reprice the starter catalog in INR.

Revision ID: b7204ef26591
Revises: 1d8856c4f192
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "b7204ef26591"
down_revision: Union[str, Sequence[str], None] = "1d8856c4f192"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

STARTER_PRICES = (
    ("Sunday Carryall", "68.00", "4290.00"),
    ("Form Study No. 02", "42.00", "2890.00"),
    ("Field Journal", "24.00", "890.00"),
    ("Soft Light Lamp", "96.00", "6490.00"),
    ("Everyday Bottle", "36.00", "1290.00"),
    ("Sunday Market Bowl", "54.00", "3590.00"),
    ("Pocket Camera Strap", "32.00", "1990.00"),
    ("Small Hours Candle", "28.00", "1190.00"),
)


def upgrade() -> None:
    connection = op.get_bind()
    for name, previous_price, rupee_price in STARTER_PRICES:
        connection.execute(
            sa.text("UPDATE store_products SET price = :rupee_price WHERE name = :name AND price = :previous_price"),
            {"name": name, "previous_price": previous_price, "rupee_price": rupee_price},
        )


def downgrade() -> None:
    connection = op.get_bind()
    for name, previous_price, rupee_price in STARTER_PRICES:
        connection.execute(
            sa.text("UPDATE store_products SET price = :previous_price WHERE name = :name AND price = :rupee_price"),
            {"name": name, "previous_price": previous_price, "rupee_price": rupee_price},
        )