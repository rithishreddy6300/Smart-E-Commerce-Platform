"""Add delivery addresses and customer-visible order tracking statuses.

Revision ID: c193a054bc7f
Revises: b7204ef26591
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "c193a054bc7f"
down_revision: Union[str, Sequence[str], None] = "b7204ef26591"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("store_orders", sa.Column("delivery_name", sa.String(length=120), nullable=True))
    op.add_column("store_orders", sa.Column("delivery_phone", sa.String(length=30), nullable=True))
    op.add_column("store_orders", sa.Column("address_line", sa.String(length=255), nullable=True))
    op.add_column("store_orders", sa.Column("city", sa.String(length=100), nullable=True))
    op.add_column("store_orders", sa.Column("state", sa.String(length=100), nullable=True))
    op.add_column("store_orders", sa.Column("postal_code", sa.String(length=20), nullable=True))
    connection = op.get_bind()
    connection.execute(sa.text("UPDATE store_orders SET order_status = 'confirmed' WHERE order_status = 'processing'"))
    connection.execute(sa.text("UPDATE store_orders SET order_status = 'dispatched' WHERE order_status = 'shipped'"))


def downgrade() -> None:
    op.drop_column("store_orders", "postal_code")
    op.drop_column("store_orders", "state")
    op.drop_column("store_orders", "city")
    op.drop_column("store_orders", "address_line")
    op.drop_column("store_orders", "delivery_phone")
    op.drop_column("store_orders", "delivery_name")