from decimal import Decimal

from sqlalchemy import select

from api.app.database import SessionLocal
from api.app.models import Product

PRODUCTS = [
    ("Sunday Carryall", "A roomy everyday bag in sturdy washed canvas.", "Carry", "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=85", "4290.00", 14, 97),
    ("Form Study No. 02", "Hand-thrown stoneware, made for slow mornings.", "Home", "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=900&q=85", "2890.00", 18, 89),
    ("Field Journal", "Recycled paper, linen cover, 160 quiet pages.", "Paper", "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=85", "890.00", 32, 81),
    ("Soft Light Lamp", "A warm little pool of light for the late hours.", "Home", "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85", "6490.00", 7, 78),
    ("Everyday Bottle", "Double-wall stainless steel, built to keep close.", "Carry", "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=85", "1290.00", 24, 73),
    ("Sunday Market Bowl", "A generous shape for fruit, keys, or nothing at all.", "Home", "https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=900&q=85", "3590.00", 10, 69),
    ("Pocket Camera Strap", "Soft woven cotton with brass hardware.", "Carry", "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85", "1990.00", 16, 64),
    ("Small Hours Candle", "Cedar, fig leaf, and a little bit of rain.", "Home", "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=900&q=85", "1190.00", 21, 61),
]


def main():
    with SessionLocal() as db:
        if db.scalar(select(Product.id).limit(1)):
            print("Products already exist; leaving the catalog unchanged.")
            return
        db.add_all([
            Product(
                name=name,
                description=description,
                category=category,
                image_url=image_url,
                price=Decimal(price),
                stock=stock,
                popularity=popularity,
                active=True,
            )
            for name, description, category, image_url, price, stock, popularity in PRODUCTS
        ])
        db.commit()
        print(f"Added {len(PRODUCTS)} demo products.")


if __name__ == "__main__":
    main()