import { createAuth0Client } from '@auth0/auth0-spa-js'

const domain = import.meta.env.VITE_AUTH0_DOMAIN
const clientId = import.meta.env.VITE_AUTH0_CLIENT_ID
const audience = import.meta.env.VITE_AUTH0_AUDIENCE
let clientPromise

export function isAuth0Configured() {
  return Boolean(domain && clientId && audience)
}

export function getAuth0Client() {
  if (!isAuth0Configured()) throw new Error('Auth0 is not configured for this app.')
  if (!clientPromise) {
    clientPromise = createAuth0Client({
      domain,
      clientId,
      authorizationParams: {
        audience,
        redirect_uri: window.location.origin,
        scope: 'openid profile email',
      },
    })
  }
  return clientPromise
}