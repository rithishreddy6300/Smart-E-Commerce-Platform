import { useEffect, useState } from "react";
import {
    ArrowRight,
    ArrowUpRight,
    Bell,
    CircleCheck,
    Clock3,
    MoreHorizontal,
    Check,
    Heart,
    Leaf,
    Menu,
    Minus,
    PackageCheck,
    Plus,
    Search,
    ShoppingBag,
    Sparkles,
    UserRound,
    X,
} from "lucide-react";
import { api, API_BASE, getToken, setToken } from "./api";
import { getAuth0Client, isAuth0Configured } from "./auth0";
import { QRCodeSVG } from "qrcode.react";
import "./auth.css";
import "./App.css";
import "./brand.css";
import "./checkout.css";

const starterProducts = [
    {
        id: 1,
        name: "Sunday Carryall",
        description: "A roomy everyday bag in sturdy washed canvas.",
        price: 4290,
        stock: 14,
        category: "Carry",
        image_url:
            "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=85",
        popularity: 97,
    },
    {
        id: 2,
        name: "Form Study No. 02",
        description: "Hand-thrown stoneware, made for slow mornings.",
        price: 2890,
        stock: 18,
        category: "Home",
        image_url:
            "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=900&q=85",
        popularity: 89,
    },
    {
        id: 3,
        name: "Field Journal",
        description: "Recycled paper, linen cover, 160 quiet pages.",
        price: 890,
        stock: 32,
        category: "Paper",
        image_url:
            "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=85",
        popularity: 81,
    },
    {
        id: 4,
        name: "Soft Light Lamp",
        description: "A warm little pool of light for the late hours.",
        price: 6490,
        stock: 7,
        category: "Home",
        image_url:
            "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85",
        popularity: 78,
    },
    {
        id: 5,
        name: "Everyday Bottle",
        description: "Double-wall stainless steel, built to keep close.",
        price: 1290,
        stock: 24,
        category: "Carry",
        image_url:
            "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=85",
        popularity: 73,
    },
    {
        id: 6,
        name: "Sunday Market Bowl",
        description: "A generous shape for fruit, keys, or nothing at all.",
        price: 3590,
        stock: 10,
        category: "Home",
        image_url:
            "https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=900&q=85",
        popularity: 69,
    },
    {
        id: 7,
        name: "Pocket Camera Strap",
        description: "Soft woven cotton with brass hardware.",
        price: 1990,
        stock: 16,
        category: "Carry",
        image_url:
            "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85",
        popularity: 64,
    },
    {
        id: 8,
        name: "Small Hours Candle",
        description: "Cedar, fig leaf, and a little bit of rain.",
        price: 1190,
        stock: 21,
        category: "Home",
        image_url:
            "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=900&q=85",
        popularity: 61,
    },
];

const currency = (amount) =>
    new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0,
    }).format(amount);

function Brand({ className = "brand-link" }) {
    return (
        <a className={className} href="#top" aria-label="RR Stores home">
            <img src="/rr-catering-logo.svg" alt="RR Catering" />
            <span>RR Stores</span>
        </a>
    );
}

const orderStages = ["confirmed", "packed", "dispatched", "out_for_delivery", "delivered"];

function OrderTracker({ order }) {
    const currentIndex = orderStages.indexOf(order.order_status);
    return (
        <ol className="order-tracker">
            {orderStages.map((stage, index) => (
                <li className={index <= currentIndex ? "complete" : "upcoming"} key={stage}>
                    <span className="tracker-marker">{index < currentIndex ? <CircleCheck size={14} /> : <span />}</span>
                    <span>{stage.replaceAll("_", " ")}</span>
                    {index === currentIndex && <strong>Current</strong>}
                </li>
            ))}
            {order.order_status === "cancelled" && <li className="cancelled">Order cancelled</li>}
        </ol>
    );
}

function App() {
    const [products, setProducts] = useState(starterProducts);
    const [categories, setCategories] = useState([
        "All",
        "Carry",
        "Home",
        "Paper",
    ]);
    const [cart, setCart] = useState({ items: [], total: 0 });
    const [user, setUser] = useState(null);
    const [orders, setOrders] = useState([]);
    const [notifications, setNotifications] = useState([]);
    const [overlay, setOverlay] = useState("");
    const [checkoutForm, setCheckoutForm] = useState({
        payment_method: "online",
        delivery_name: "",
        delivery_phone: "",
        address_line: "",
        city: "",
        state: "",
        postal_code: "",
    });
    const [checkoutResult, setCheckoutResult] = useState(null);
    const [successOrder, setSuccessOrder] = useState(null);
    const [trackingOrderId, setTrackingOrderId] = useState(null);
    const [authMode, setAuthMode] = useState("login");
    const [form, setForm] = useState({ name: "", email: "", password: "" });
    const [category, setCategory] = useState("All");
    const [priceBand, setPriceBand] = useState("any");
    const [sort, setSort] = useState("popular");
    const [search, setSearch] = useState("");
    const [busy, setBusy] = useState(false);
    const [toast, setToast] = useState("");
    const [orderNotice, setOrderNotice] = useState(() => {
        const checkout = new URLSearchParams(window.location.search).get(
            "checkout",
        );
        if (checkout === "success")
            return "Payment received. Your order is on its way to being a good thing.";
        if (checkout === "cancel")
            return "Checkout was cancelled. Your order is still waiting in your account.";
        return "";
    });

    useEffect(() => {
        let active = true;
        api("/products?sort=popular")
            .then((data) => {
                if (!active || !data.length) return;
                setProducts(data);
                setCategories([
                    "All",
                    ...new Set(data.map((product) => product.category)),
                ]);
            })
            .catch(() => { });
        const params = new URLSearchParams(window.location.search);
        const returnedOrderId = params.get("order_id");
        if (params.get("checkout") === "success" && returnedOrderId && getToken()) {
            api(`/orders/${returnedOrderId}`)
                .then((order) => {
                    if (order.payment_status === "paid") {
                        setSuccessOrder(order);
                        setOrderNotice("Your order is confirmed. Wait for a while; it will reach you.");
                    } else {
                        setOrderNotice("Payment received. Your order status is updating.");
                    }
                })
                .catch(() => { });
        }
        if (params.has("checkout"))
            window.history.replaceState({}, "", window.location.pathname);
        return () => {
            active = false;
        };
    }, []);

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        if (!params.has("code") || !params.has("state") || !isAuth0Configured())
            return;
        let active = true;
        async function completeSocialLogin() {
            try {
                const client = await getAuth0Client();
                await client.handleRedirectCallback();
                const accessToken = await client.getTokenSilently();
                const result = await api("/auth/auth0", {
                    method: "POST",
                    body: { access_token: accessToken },
                });
                if (!active) return;
                setToken(result.access_token);
                setUser(result.user);
                window.history.replaceState({}, "", window.location.pathname);
                const [nextCart, nextNotifications] = await Promise.all([
                    api("/cart"),
                    api("/notifications"),
                ]);
                if (active) {
                    setCart(nextCart);
                    setNotifications(nextNotifications);
                }
            } catch (error) {
                if (active) setToast(error.message);
            }
        }
        completeSocialLogin();
        return () => {
            active = false;
        };
    }, []);

    useEffect(() => {
        if (!getToken()) return undefined;
        let active = true;
        api("/auth/me")
            .then((profile) => {
                if (!active) return;
                setUser(profile);
                return Promise.all([api("/cart"), api("/notifications")]);
            })
            .then((data) => {
                if (active && data) {
                    setCart(data[0]);
                    setNotifications(data[1]);
                }
            })
            .catch(() => {
                if (active) setToken("");
            });
        return () => {
            active = false;
        };
    }, []);

    useEffect(() => {
        if (!toast) return undefined;
        const timer = window.setTimeout(() => setToast(""), 3200);
        return () => window.clearTimeout(timer);
    }, [toast]);

    useEffect(() => {
        if (!user || !getToken()) return undefined;
        const socket = new WebSocket(
            `${API_BASE.replace(/^http/, "ws")}/ws?token=${encodeURIComponent(getToken())}`,
        );
        socket.onmessage = (event) => {
            const message = JSON.parse(event.data);
            if (message.type === "cart_updated")
                api("/cart")
                    .then(setCart)
                    .catch(() => { });
            else {
                setToast(message.message);
                api("/notifications")
                    .then(setNotifications)
                    .catch(() => { });
                if (overlay === "account") {
                    api("/orders")
                        .then(setOrders)
                        .catch(() => { });
                }
            }
        };
        return () => socket.close();
    }, [user, overlay]);

    useEffect(() => {
        if (overlay !== "account" || !user) return;
        Promise.all([api("/orders"), api("/notifications")])
            .then(([nextOrders, nextNotifications]) => {
                setOrders(nextOrders);
                setNotifications(nextNotifications);
            })
            .catch((error) => setToast(error.message));
    }, [overlay, user]);

    const visibleProducts = products
        .filter((product) => category === "All" || product.category === category)
        .filter((product) =>
            product.name.toLowerCase().includes(search.trim().toLowerCase()),
        )
        .filter((product) =>
            priceBand === "under50"
                ? product.price < 2500
                : priceBand === "50to100"
                    ? product.price >= 2500 && product.price <= 5000
                    : priceBand === "over100"
                        ? product.price > 5000
                        : true,
        )
        .sort((left, right) =>
            sort === "price_asc"
                ? left.price - right.price
                : sort === "price_desc"
                    ? right.price - left.price
                    : (right.popularity || 0) - (left.popularity || 0),
        );

    async function addToCart(product) {
        if (!user) {
            setAuthMode("login");
            setOverlay("auth");
            setToast("Sign in to keep your good finds together.");
            return;
        }
        try {
            setCart(
                await api("/cart/items", {
                    method: "POST",
                    body: { product_id: product.id, quantity: 1 },
                }),
            );
            setToast(`${product.name} added to your bag.`);
            setOverlay("cart");
        } catch (error) {
            setToast(error.message);
        }
    }

    async function changeQuantity(productId, quantity) {
        try {
            const next =
                quantity < 1
                    ? await api(`/cart/items/${productId}`, { method: "DELETE" })
                    : await api(`/cart/items/${productId}`, {
                        method: "PATCH",
                        body: { quantity },
                    });
            setCart(next);
        } catch (error) {
            setToast(error.message);
        }
    }

    async function submitAuth(event) {
        event.preventDefault();
        setBusy(true);
        try {
            const result = await api(
                authMode === "register" ? "/auth/register" : "/auth/login",
                { method: "POST", body: form },
            );
            setToken(result.access_token);
            setUser(result.user);
            setOverlay("");
            setForm({ name: "", email: "", password: "" });
            const [nextCart, nextNotifications] = await Promise.all([
                api("/cart"),
                api("/notifications"),
            ]);
            setCart(nextCart);
            setNotifications(nextNotifications);
            setToast(`Good to have you here, ${result.user.name.split(" ")[0]}.`);
        } catch (error) {
            setToast(error.message);
        } finally {
            setBusy(false);
        }
    }

    async function signInWithAuth0() {
        try {
            const client = await getAuth0Client();
            await client.loginWithRedirect();
        } catch (error) {
            setToast(error.message);
        }
    }

    function openCheckout() {
        if (!user) {
            setOverlay("auth");
            return;
        }
        setCheckoutForm((current) => ({
            ...current,
            delivery_name: current.delivery_name || user.name,
        }));
        setOverlay("checkout");
    }

    async function checkout(event) {
        event.preventDefault();
        setBusy(true);
        try {
            const result = await api("/orders/checkout", {
                method: "POST",
                body: checkoutForm,
            });
            setCart({ items: [], total: 0 });
            setCheckoutResult(result);
            if (result.payment_method === "cod") {
                setSuccessOrder(result);
                setOrderNotice("Your order is confirmed. Wait for a while; it will reach you.");
                setOverlay("success");
                Promise.all([api("/orders"), api("/notifications")]).then(([nextOrders, nextNotifications]) => {
                    setOrders(nextOrders);
                    setNotifications(nextNotifications);
                }).catch(() => { });
            } else {
                setOverlay("payment");
            }
        } catch (error) {
            setToast(error.message);
        } finally {
            setBusy(false);
        }
    }

    async function confirmDemoPayment() {
        if (!checkoutResult) return;
        setBusy(true);
        try {
            const result = await api(`/orders/${checkoutResult.order_id}/confirm-demo-payment`, { method: "POST" });
            const order = await api(`/orders/${result.order_id}`);
            setSuccessOrder(order);
            setOrderNotice("Your order is confirmed. Wait for a while; it will reach you.");
            setOverlay("success");
            const [nextOrders, nextNotifications] = await Promise.all([api("/orders"), api("/notifications")]);
            setOrders(nextOrders);
            setNotifications(nextNotifications);
        } catch (error) {
            setToast(error.message);
        } finally {
            setBusy(false);
        }
    }

    async function refreshStripePayment() {
        if (!checkoutResult) return;
        try {
            const order = await api(`/orders/${checkoutResult.order_id}`);
            if (order.payment_status !== "paid") {
                setToast("Payment is still being confirmed. Refresh again in a moment.");
                return;
            }
            setSuccessOrder(order);
            setOrderNotice("Your order is confirmed. Wait for a while; it will reach you.");
            setOrders(await api("/orders"));
            setOverlay("success");
        } catch (error) {
            setToast(error.message);
        }
    }

    function signOut() {
        setToken("");
        setUser(null);
        setCart({ items: [], total: 0 });
        setNotifications([]);
        setOrders([]);
        setOverlay("");
        setToast("You have signed out.");
    }

    async function markRead(item) {
        if (item.is_read) return;
        try {
            const updated = await api(`/notifications/${item.id}/read`, {
                method: "POST",
            });
            setNotifications((current) =>
                current.map((entry) => (entry.id === updated.id ? updated : entry)),
            );
        } catch (error) {
            setToast(error.message);
        }
    }

    const bagCount = cart.items.reduce((sum, item) => sum + item.quantity, 0);
    const unreadCount = notifications.filter((item) => !item.is_read).length;

    return (
        <div className="site-shell">
            <div className="announcement">
                <span>Small things, thoughtfully made.</span>
                <span>
                    Free shipping on orders over ₹5,000 <ArrowRight size={13} />
                </span>
            </div>
            <header className="site-header">
                <Brand />
                <nav className="main-nav" aria-label="Main navigation">
                    <a href="#shop">Shop all</a>
                    <a href="#story">Our point of view</a>
                    <a href="#newsletter">The Sunday note</a>
                </nav>
                <div className="header-actions">
                    <button
                        className="icon-button search-toggle"
                        title="Search products"
                        onClick={() => document.getElementById("product-search")?.focus()}
                    >
                        <Search size={19} />
                    </button>
                    <button
                        className="icon-button account-button"
                        title={user ? "Open your account" : "Sign in"}
                        onClick={() => setOverlay(user ? "account" : "auth")}
                    >
                        <UserRound size={19} />
                        <span className="action-label">{user ? "Account" : "Sign in"}</span>
                    </button>
                    {user && (
                        <button
                            className="icon-button notification-button"
                            title="Notifications"
                            onClick={() => setOverlay("account")}
                        >
                            <Bell size={19} />
                            {unreadCount > 0 && (
                                <span className="notification-dot">{unreadCount}</span>
                            )}
                        </button>
                    )}
                    <button
                        className="icon-button bag-button"
                        title="Open shopping bag"
                        onClick={() => setOverlay("cart")}
                    >
                        <ShoppingBag size={19} />
                        <span className="action-label">Bag</span>
                        <span className="bag-count">{bagCount}</span>
                    </button>
                    <button
                        className="icon-button mobile-menu"
                        title="Open menu"
                        onClick={() => setOverlay("menu")}
                    >
                        <Menu size={20} />
                    </button>
                </div>
            </header>

            <main id="top">
                {orderNotice && (
                    <div className="order-notice">
                        <Check size={16} />
                        {orderNotice}
                        <button title="Dismiss message" onClick={() => setOrderNotice("")}>
                            <X size={15} />
                        </button>
                    </div>
                )}
                <section className="hero-section">
                    <div className="hero-copy">
                        <p className="eyebrow">
                            <Sparkles size={14} /> A little more considered
                        </p>
                        <h1>
                            Make room for
                            <br />
                            <em>better things.</em>
                        </h1>
                        <p className="hero-description">
                            Objects with a point of view. Made to be used, kept, and loved for
                            a long time.
                        </p>
                        <a className="primary-link" href="#shop">
                            Find your next favorite <ArrowRight size={16} />
                        </a>
                        <div className="hero-footnote">
                            <span>01 / 03</span>
                            <span className="footnote-rule" />
                            <span>Made with intention, found for you.</span>
                        </div>
                    </div>
                    <div className="hero-image-wrap">
                        <img
                            src="https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=1400&q=90"
                            alt="Sunlit handmade ceramic pieces arranged on a studio shelf"
                        />
                        <div className="image-caption">
                            <span>Objects for everyday rituals</span>
                            <ArrowUpRight size={15} />
                        </div>
                        <div className="image-stamp">
                            <span>EST.</span>
                            <strong>2024</strong>
                            <span>
                                GOOD
                                <br />
                                THINGS
                            </span>
                        </div>
                    </div>
                    <div className="hero-side-note">
                        CURATED FOR SLOWER LIVING <span>·</span> INDEPENDENT MAKERS{" "}
                        <span>·</span> GOOD DESIGN, NO FUSS
                    </div>
                </section>

                <section className="values-strip" aria-label="Our values">
                    <div>
                        <Leaf size={17} />
                        <span>Made to be kept</span>
                    </div>
                    <span className="values-separator">/</span>
                    <div>
                        <PackageCheck size={17} />
                        <span>Small-batch makers</span>
                    </div>
                    <span className="values-separator">/</span>
                    <div>
                        <Heart size={17} />
                        <span>Everyday, elevated</span>
                    </div>
                    <a href="#story">
                        The way we choose <ArrowUpRight size={14} />
                    </a>
                </section>

                <section className="shop-section" id="shop">
                    <div className="section-heading">
                        <div>
                            <p className="eyebrow">A good place to start</p>
                            <h2>
                                Things worth keeping<span>.</span>
                            </h2>
                        </div>
                        <p className="section-aside">
                            Useful, beautiful, and just a little unexpected.
                            <br />A collection that feels like you.
                        </p>
                    </div>
                    <div className="shop-toolbar">
                        <div className="category-list" aria-label="Filter by category">
                            {categories.map((item) => (
                                <button
                                    key={item}
                                    className={
                                        category === item
                                            ? "category-chip selected"
                                            : "category-chip"
                                    }
                                    onClick={() => setCategory(item)}
                                >
                                    {item}
                                </button>
                            ))}
                        </div>
                        <div className="shop-filters">
                            <label className="search-field">
                                <Search size={16} />
                                <input
                                    id="product-search"
                                    type="search"
                                    value={search}
                                    onChange={(event) => setSearch(event.target.value)}
                                    placeholder="Find something"
                                />
                            </label>
                            <label className="select-label">
                                <span className="sr-only">Filter by price</span>
                                <select
                                    value={priceBand}
                                    onChange={(event) => setPriceBand(event.target.value)}
                                >
                                    <option value="any">Any price</option>
                                    <option value="under50">Under ₹2,500</option>
                                    <option value="50to100">₹2,500 – ₹5,000</option>
                                    <option value="over100">Over ₹5,000</option>
                                </select>
                            </label>
                            <label className="select-label sort-select">
                                <span className="sr-only">Sort products</span>
                                <select
                                    value={sort}
                                    onChange={(event) => setSort(event.target.value)}
                                >
                                    <option value="popular">Most loved</option>
                                    <option value="price_asc">Price: low to high</option>
                                    <option value="price_desc">Price: high to low</option>
                                </select>
                            </label>
                        </div>
                    </div>
                    <div className="product-grid">
                        {visibleProducts.map((product, index) => (
                            <article
                                className="product-card"
                                key={product.id}
                                style={{ "--card-index": index }}
                            >
                                <div className="product-image-wrap">
                                    <img
                                        src={product.image_url}
                                        alt={product.name}
                                        loading="lazy"
                                    />
                                    {index === 0 && (
                                        <span className="product-tag">Community favorite</span>
                                    )}
                                    <button
                                        className="quick-add"
                                        title={`Add ${product.name} to bag`}
                                        onClick={() => addToCart(product)}
                                    >
                                        <Plus size={18} />
                                        <span>Add to bag</span>
                                    </button>
                                </div>
                                <div className="product-meta">
                                    <div>
                                        <p className="product-category">{product.category}</p>
                                        <h3>{product.name}</h3>
                                    </div>
                                    <span className="product-price">
                                        {currency(product.price)}
                                    </span>
                                </div>
                                <p className="product-description">{product.description}</p>
                            </article>
                        ))}
                        {visibleProducts.length === 0 && (
                            <div className="no-results">
                                <Search size={22} />
                                <p>No finds this time.</p>
                                <button
                                    onClick={() => {
                                        setSearch("");
                                        setCategory("All");
                                        setPriceBand("any");
                                    }}
                                >
                                    Clear filters
                                </button>
                            </div>
                        )}
                    </div>
                    <div className="shop-bottom">
                        <span>
                            Showing {visibleProducts.length} of {products.length} considered
                            things
                        </span>
                        <a href="#shop">
                            Back to the top <ArrowUpRight size={14} />
                        </a>
                    </div>
                </section>

                <section className="story-section" id="story">
                    <div className="story-image">
                        <img
                            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=85"
                            alt="A quiet independent shop filled with well-made objects"
                            loading="lazy"
                        />
                        <span>THE RR STORES WAY · VOL. 01</span>
                    </div>
                    <div className="story-copy">
                        <p className="eyebrow">A note on buying less</p>
                        <h2>
                            Choose things
                            <br />
                            that <em>stay.</em>
                        </h2>
                        <p>
                            We look for the pieces that earn their place. Thoughtful
                            materials, honest craft, a useful little detail. No endless
                            scroll, no throwaway stuff. Just good things, chosen carefully.
                        </p>
                        <a className="text-link" href="#newsletter">
                            A little more about us <ArrowRight size={16} />
                        </a>
                        <div className="story-number">FN — 01</div>
                    </div>
                </section>
                <section className="newsletter-section" id="newsletter">
                    <div>
                        <p className="eyebrow">A note for your Sunday</p>
                        <h2>
                            Good things, <em>occasionally.</em>
                        </h2>
                    </div>
                    <form
                        onSubmit={(event) => {
                            event.preventDefault();
                            setToast("You’re on the list. See you Sunday.");
                            event.currentTarget.reset();
                        }}
                    >
                        <label className="sr-only" htmlFor="newsletter-email">
                            Email address
                        </label>
                        <input
                            id="newsletter-email"
                            type="email"
                            required
                            placeholder="Your email address"
                        />
                        <button title="Join the Sunday note">
                            <ArrowRight size={18} />
                        </button>
                    </form>
                    <p className="newsletter-privacy">
                        A thoughtful note now and then. No noise, ever.
                    </p>
                </section>
            </main>

            <footer className="site-footer">
                <Brand />
                <span>© 2026 RR Stores</span>
                <span>Chosen with care, shipped with care.</span>
                <span className="developer-credit">Developer: RithishAnu</span>
                <a href="http://localhost:8001/admin/" target="_blank" rel="noreferrer">
                    Studio access <ArrowUpRight size={13} />
                </a>
            </footer>

            {overlay && (
                <div
                    className="overlay-scrim"
                    onMouseDown={(event) => {
                        if (event.target === event.currentTarget) setOverlay("");
                    }}
                >
                    {overlay === "cart" && (
                        <aside className="side-panel cart-panel" aria-label="Shopping bag">
                            <div className="panel-top">
                                <div>
                                    <p className="eyebrow">A good little collection</p>
                                    <h2>
                                        Your bag <span>({bagCount})</span>
                                    </h2>
                                </div>
                                <button
                                    className="icon-button"
                                    title="Close bag"
                                    onClick={() => setOverlay("")}
                                >
                                    <X size={20} />
                                </button>
                            </div>
                            {!user && (
                                <div className="empty-cart">
                                    <ShoppingBag size={26} />
                                    <h3>Your bag starts here.</h3>
                                    <p>
                                        Sign in to save your finds and pick up where you left off.
                                    </p>
                                    <button
                                        className="panel-primary"
                                        onClick={() => {
                                            setAuthMode("login");
                                            setOverlay("auth");
                                        }}
                                    >
                                        Sign in to continue <ArrowRight size={15} />
                                    </button>
                                </div>
                            )}
                            {user && cart.items.length === 0 && (
                                <div className="empty-cart">
                                    <ShoppingBag size={26} />
                                    <h3>Nothing in here just yet.</h3>
                                    <p>There are some very good things waiting for you.</p>
                                    <button
                                        className="panel-primary"
                                        onClick={() => {
                                            setOverlay("");
                                            document
                                                .getElementById("shop")
                                                ?.scrollIntoView({ behavior: "smooth" });
                                        }}
                                    >
                                        Explore the shop <ArrowRight size={15} />
                                    </button>
                                </div>
                            )}
                            {user && cart.items.length > 0 && (
                                <>
                                    <div className="cart-lines">
                                        {cart.items.map((item) => (
                                            <article className="cart-line" key={item.product_id}>
                                                <img src={item.image_url} alt="" />
                                                <div className="cart-line-info">
                                                    <h3>{item.name}</h3>
                                                    <span>{currency(item.price)}</span>
                                                    <div className="quantity-control">
                                                        <button
                                                            title="Remove one"
                                                            onClick={() =>
                                                                changeQuantity(
                                                                    item.product_id,
                                                                    item.quantity - 1,
                                                                )
                                                            }
                                                        >
                                                            <Minus size={13} />
                                                        </button>
                                                        <span>{item.quantity}</span>
                                                        <button
                                                            title="Add one"
                                                            onClick={() =>
                                                                changeQuantity(
                                                                    item.product_id,
                                                                    item.quantity + 1,
                                                                )
                                                            }
                                                        >
                                                            <Plus size={13} />
                                                        </button>
                                                    </div>
                                                </div>
                                                <button
                                                    className="line-total"
                                                    title="Remove item"
                                                    onClick={() => changeQuantity(item.product_id, 0)}
                                                >
                                                    {currency(item.line_total)}
                                                    <X size={14} />
                                                </button>
                                            </article>
                                        ))}
                                    </div>
                                    <div className="cart-summary">
                                        <div>
                                            <span>Subtotal</span>
                                            <strong>{currency(cart.total)}</strong>
                                        </div>
                                        <p>
                                            {cart.total >= 5000
                                                ? "Your shipping is on us."
                                                : `You are ${currency(5000 - cart.total)} from complimentary shipping.`}
                                        </p>
                                        <button
                                            className="panel-primary"
                                            disabled={busy}
                                            onClick={openCheckout}
                                        >
                                            {busy ? "One moment…" : "Checkout"}{" "}
                                            <ArrowRight size={16} />
                                        </button>
                                        <span className="secure-note">
                                            Secure checkout · Payment details stay private
                                        </span>
                                    </div>
                                </>
                            )}
                        </aside>
                    )}

                    {overlay === "checkout" && (
                        <section className="checkout-modal" aria-label="Delivery and payment">
                            <div className="panel-top">
                                <div>
                                    <p className="eyebrow">Almost at your door</p>
                                    <h2>Delivery details</h2>
                                </div>
                                <button className="icon-button" title="Close checkout" onClick={() => setOverlay("cart")}>
                                    <X size={20} />
                                </button>
                            </div>
                            <form className="checkout-form" onSubmit={checkout}>
                                <fieldset className="payment-methods">
                                    <legend>Choose how to pay</legend>
                                    <label className={checkoutForm.payment_method === "online" ? "payment-option selected" : "payment-option"}>
                                        <input type="radio" name="payment_method" value="online" checked={checkoutForm.payment_method === "online"} onChange={() => setCheckoutForm({ ...checkoutForm, payment_method: "online" })} />
                                        <span><strong>Online payment</strong><small>Secure checkout by QR</small></span>
                                    </label>
                                    <label className={checkoutForm.payment_method === "cod" ? "payment-option selected" : "payment-option"}>
                                        <input type="radio" name="payment_method" value="cod" checked={checkoutForm.payment_method === "cod"} onChange={() => setCheckoutForm({ ...checkoutForm, payment_method: "cod" })} />
                                        <span><strong>Cash on delivery</strong><small>Pay when your order arrives</small></span>
                                    </label>
                                </fieldset>
                                <div className="delivery-fields">
                                    <label>Full name<input required maxLength="120" autoComplete="name" value={checkoutForm.delivery_name} onChange={(event) => setCheckoutForm({ ...checkoutForm, delivery_name: event.target.value })} /></label>
                                    <label>Mobile number<input required minLength="7" maxLength="30" autoComplete="tel" inputMode="tel" value={checkoutForm.delivery_phone} onChange={(event) => setCheckoutForm({ ...checkoutForm, delivery_phone: event.target.value })} /></label>
                                    <label className="address-field">Street address<input required minLength="5" maxLength="255" autoComplete="street-address" value={checkoutForm.address_line} onChange={(event) => setCheckoutForm({ ...checkoutForm, address_line: event.target.value })} /></label>
                                    <label>City<input required maxLength="100" autoComplete="address-level2" value={checkoutForm.city} onChange={(event) => setCheckoutForm({ ...checkoutForm, city: event.target.value })} /></label>
                                    <label>State<input required maxLength="100" autoComplete="address-level1" value={checkoutForm.state} onChange={(event) => setCheckoutForm({ ...checkoutForm, state: event.target.value })} /></label>
                                    <label>PIN code<input required minLength="4" maxLength="20" autoComplete="postal-code" inputMode="numeric" value={checkoutForm.postal_code} onChange={(event) => setCheckoutForm({ ...checkoutForm, postal_code: event.target.value })} /></label>
                                </div>
                                <div className="checkout-total"><span>Order total</span><strong>{currency(cart.total)}</strong></div>
                                <button className="panel-primary" disabled={busy}>
                                    {busy ? "One moment…" : checkoutForm.payment_method === "cod" ? "Place COD order" : "Continue to online payment"}
                                    <ArrowRight size={16} />
                                </button>
                                <span className="secure-note">Your address is only used to deliver this order.</span>
                            </form>
                        </section>
                    )}

                    {overlay === "payment" && checkoutResult && (
                        <section className="payment-modal" aria-label="Online payment QR">
                            <div className="panel-top">
                                <div><p className="eyebrow">Order #{checkoutResult.order_id}</p><h2>Scan to continue</h2></div>
                                <button className="icon-button" title="Close payment" onClick={() => setOverlay("account")}><X size={20} /></button>
                            </div>
                            <p className="payment-intro">{checkoutResult.demo ? `Your demo QR confirms a no-charge RR Stores checkout for ${currency(checkoutResult.total)}.` : `Scan the QR to open secure Stripe payment for ${currency(checkoutResult.total)}.`}</p>
                            <div className="qr-frame"><QRCodeSVG value={checkoutResult.checkout_url || checkoutResult.qr_text || "RR Stores"} size={224} level="M" includeMargin /></div>
                            {checkoutResult.demo ? (
                                <><p className="demo-free-note">This is free of cost for using RR Stores.</p><p className="demo-caption">Scanning shows the demo message. No payment will be collected in local demo mode.</p><button className="panel-primary" disabled={busy} onClick={confirmDemoPayment}>{busy ? "Confirming…" : "Complete free demo checkout"}<CircleCheck size={16} /></button></>
                            ) : (
                                <><a className="panel-primary payment-link" href={checkoutResult.checkout_url} target="_blank" rel="noreferrer">Open secure Stripe checkout<ArrowUpRight size={15} /></a><button className="payment-refresh" disabled={busy} onClick={refreshStripePayment}>{busy ? "Checking…" : "I paid · check order status"}</button></>
                            )}
                        </section>
                    )}

                    {overlay === "success" && successOrder && (
                        <section className="success-modal" aria-label="Order confirmed">
                            <div className="success-mark"><CircleCheck size={34} /></div>
                            <p className="eyebrow">RR Stores · Order #{successOrder.order_id || successOrder.id}</p>
                            <h2>The order is confirmed.</h2>
                            <p>Wait for a while; it will reach you.</p>
                            {successOrder.payment_method === "cod" && <span className="cod-reminder">Cash on delivery · {currency(successOrder.total)}</span>}
                            <button className="panel-primary" onClick={() => setOverlay("account")}>View order tracking<ArrowRight size={15} /></button>
                        </section>
                    )}

                    {overlay === "auth" && (
                        <section
                            className="auth-modal"
                            aria-label={
                                authMode === "login" ? "Sign in" : "Create an account"
                            }
                        >
                            <div className="auth-brand">
                                <img src="/rr-catering-logo.svg" alt="RR Catering" />
                                <span>RR Stores</span>
                            </div>
                            <div className="panel-top">
                                <div>
                                    <p className="eyebrow">A place for your good finds</p>
                                    <h2>
                                        {authMode === "login"
                                            ? "Welcome back."
                                            : "Make yourself at home."}
                                    </h2>
                                </div>
                                <button
                                    className="icon-button"
                                    title="Close"
                                    onClick={() => setOverlay("")}
                                >
                                    <X size={20} />
                                </button>
                            </div>
                            <form className="auth-form" onSubmit={submitAuth}>
                                {authMode === "register" && (
                                    <label>
                                        Your name
                                        <input
                                            required
                                            value={form.name}
                                            onChange={(event) =>
                                                setForm({ ...form, name: event.target.value })
                                            }
                                            autoComplete="name"
                                        />
                                    </label>
                                )}
                                <label>
                                    Email address
                                    <input
                                        type="email"
                                        required
                                        value={form.email}
                                        onChange={(event) =>
                                            setForm({ ...form, email: event.target.value })
                                        }
                                        autoComplete="email"
                                    />
                                </label>
                                <label>
                                    Password
                                    <input
                                        type="password"
                                        required
                                        minLength="8"
                                        value={form.password}
                                        onChange={(event) =>
                                            setForm({ ...form, password: event.target.value })
                                        }
                                        autoComplete={
                                            authMode === "login" ? "current-password" : "new-password"
                                        }
                                    />
                                </label>
                                <button className="panel-primary" disabled={busy}>
                                    {busy
                                        ? "One moment…"
                                        : authMode === "login"
                                            ? "Sign in"
                                            : "Create account"}{" "}
                                    <ArrowRight size={15} />
                                </button>
                            </form>
                            {isAuth0Configured() && (
                                <>
                                    <div className="auth-divider">
                                        <span>or</span>
                                    </div>
                                    <button
                                        className="social-auth-button"
                                        onClick={signInWithAuth0}
                                    >
                                        Continue with Google or Facebook <ArrowRight size={14} />
                                    </button>
                                </>
                            )}
                            <p className="auth-switch">
                                {authMode === "login"
                                    ? "New around here?"
                                    : "Already have an account?"}{" "}
                                <button
                                    onClick={() =>
                                        setAuthMode(authMode === "login" ? "register" : "login")
                                    }
                                >
                                    {authMode === "login" ? "Create an account" : "Sign in"}
                                </button>
                            </p>
                            <span className="auth-note">
                                Your social account stays with Auth0.
                            </span>
                        </section>
                    )}

                    {overlay === "account" && (
                        <section className="account-modal" aria-label="Your account">
                            <div className="panel-top">
                                <div>
                                    <p className="eyebrow">Your corner of RR Stores</p>
                                    <h2>Hello, {user?.name.split(" ")[0]}.</h2>
                                </div>
                                <button
                                    className="icon-button"
                                    title="Close account"
                                    onClick={() => setOverlay("")}
                                >
                                    <X size={20} />
                                </button>
                            </div>
                            <div className="account-section">
                                <h3>
                                    <PackageCheck size={16} /> Recent orders
                                </h3>
                                {orders.length === 0 ? (
                                    <p className="account-empty">
                                        No orders just yet. Your first good thing is waiting.
                                    </p>
                                ) : (
                                    orders.map((order) => (
                                        <article className="account-order" key={order.id}>
                                            <div className="account-order-info">
                                                <strong>Order #{order.id} · {currency(order.total)}</strong>
                                                <span>{new Date(order.created_at).toLocaleDateString()} · {order.payment_method === "cod" ? "Cash on delivery" : order.payment_method === "demo_qr" ? "Online demo" : "Online payment"}</span>
                                                <span>{order.address_line}, {order.city}, {order.state} {order.postal_code}</span>
                                            </div>
                                            <span className={`status-pill ${order.payment_status}`}>{order.order_status.replaceAll("_", " ")}</span>
                                            <button className="order-track-toggle" aria-label={`Track order ${order.id}`} aria-expanded={trackingOrderId === order.id} title="Order status and tracking" onClick={() => setTrackingOrderId(trackingOrderId === order.id ? null : order.id)}><MoreHorizontal size={20} /></button>
                                            {trackingOrderId === order.id && <div className="order-tracker-panel"><div className="tracker-heading"><Clock3 size={15} /><span>Order progress</span></div><OrderTracker order={order} /></div>}
                                        </article>
                                    ))
                                )}
                            </div>
                            <div className="account-section">
                                <h3>
                                    <Bell size={16} /> Notes for you
                                </h3>
                                {notifications.length === 0 ? (
                                    <p className="account-empty">
                                        No notes yet. We’ll keep you posted here.
                                    </p>
                                ) : (
                                    notifications.slice(0, 5).map((item) => (
                                        <button
                                            className={
                                                item.is_read
                                                    ? "notification-item read"
                                                    : "notification-item"
                                            }
                                            key={item.id}
                                            onClick={() => markRead(item)}
                                        >
                                            <span>{item.message}</span>
                                            <small>
                                                {new Date(item.created_at).toLocaleDateString()}
                                            </small>
                                        </button>
                                    ))
                                )}
                            </div>
                            <button className="sign-out-button" onClick={signOut}>
                                Sign out <ArrowRight size={14} />
                            </button>
                        </section>
                    )}

                    {overlay === "menu" && (
                        <section className="mobile-menu-panel">
                            <div className="panel-top">
                                <Brand />
                                <button
                                    className="icon-button"
                                    title="Close menu"
                                    onClick={() => setOverlay("")}
                                >
                                    <X size={20} />
                                </button>
                            </div>
                            <a href="#shop" onClick={() => setOverlay("")}>
                                Shop all <ArrowRight size={16} />
                            </a>
                            <a href="#story" onClick={() => setOverlay("")}>
                                Our point of view <ArrowRight size={16} />
                            </a>
                            <a href="#newsletter" onClick={() => setOverlay("")}>
                                The Sunday note <ArrowRight size={16} />
                            </a>
                        </section>
                    )}
                </div>
            )}
            {toast && (
                <div className="toast-message" role="status">
                    <Check size={16} />
                    {toast}
                    <button title="Dismiss" onClick={() => setToast("")}>
                        <X size={14} />
                    </button>
                </div>
            )}
        </div>
    );
}

export default App;
