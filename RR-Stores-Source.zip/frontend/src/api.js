export const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export function getToken() {
    return window.localStorage.getItem('fieldnotes-token') || ''
}

export function setToken(token) {
    if (token) window.localStorage.setItem('fieldnotes-token', token)
    else window.localStorage.removeItem('fieldnotes-token')
}

export async function api(path, options = {}) {
    const headers = new Headers(options.headers || {})
    const isForm = options.body instanceof FormData
    if (options.body && !isForm) headers.set('Content-Type', 'application/json')
    if (getToken()) headers.set('Authorization', `Bearer ${getToken()}`)
    const response = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers,
        body: options.body && !isForm ? JSON.stringify(options.body) : options.body,
    })
    const data = response.status === 204 ? null : await response.json().catch(() => null)
    if (!response.ok) throw new Error(data?.detail || 'Something went wrong. Please try again.')
    return data
}