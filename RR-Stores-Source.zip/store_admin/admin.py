from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from uuid import uuid4

from django import forms
from django.contrib import admin
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.db.models import Sum
from django.utils import timezone

from api.app.notifications import send_email
from api.app.security import hash_password

from .models import CartItem, Notification, Order, OrderItem, Payment, Product, StoreUser


class StoreAdminSite(admin.AdminSite):
    site_header = "RR Stores"
    site_title = "RR Stores Admin"
    index_title = "Store overview"

    def index(self, request, extra_context=None):
        today = timezone.localdate()
        start = today - timedelta(days=6)
        daily_sales = {start + timedelta(days=offset): Decimal("0.00") for offset in range(7)}
        paid_orders = Order.objects.filter(payment_status="paid")
        for created_at, amount in paid_orders.filter(created_at__date__gte=start).values_list("created_at", "total"):
            sale_day = timezone.localtime(created_at).date()
            if sale_day in daily_sales:
                daily_sales[sale_day] += amount
        top_products = (
            OrderItem.objects.filter(order__payment_status="paid")
            .values("product__name")
            .annotate(units=Sum("quantity"))
            .order_by("-units")[:5]
        )
        context = {
            "total_sales": paid_orders.aggregate(total=Sum("total"))["total"] or Decimal("0.00"),
            "paid_orders": paid_orders.count(),
            "total_customers": StoreUser.objects.filter(role="customer").count(),
            "low_stock": Product.objects.filter(active=True, stock__lte=5).order_by("stock", "name")[:8],
            "top_products": top_products,
            "revenue_labels": [day.strftime("%b %d") for day in daily_sales],
            "revenue_values": [float(amount) for amount in daily_sales.values()],
            "csv_report_url": "/admin/reports/sales.csv",
            "pdf_report_url": "/admin/reports/sales.pdf",
        }
        context.update(extra_context or {})
        return super().index(request, context)


class StoreUserAdminForm(forms.ModelForm):
    password = forms.CharField(required=False, widget=forms.PasswordInput, help_text="Optional when creating an account; can be set later through sign-in.")

    class Meta:
        model = StoreUser
        fields = ("name", "email", "role")


class StoreUserAdmin(admin.ModelAdmin):
    form = StoreUserAdminForm
    list_display = ("email", "name", "role", "created_at")
    list_filter = ("role",)
    list_editable = ("role",)
    search_fields = ("email", "name")
    readonly_fields = ("created_at", "password_hash")
    fields = ("name", "email", "role", "password", "created_at", "password_hash")

    def delete_model(self, request, obj):
        if obj.store_orders.exists():
            obj.name = "Deleted customer"
            obj.email = f"deleted+{obj.pk}@deleted.rrstores"
            obj.password_hash = ""
            obj.save(update_fields=("name", "email", "password_hash"))
            return
        super().delete_model(request, obj)

    def delete_queryset(self, request, queryset):
        for user in queryset.iterator():
            self.delete_model(request, user)

    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_at = timezone.now()
        if form.cleaned_data.get("password"):
            obj.password_hash = hash_password(form.cleaned_data["password"])
        elif not change:
            obj.password_hash = ""
        super().save_model(request, obj, form, change)


class ProductAdminForm(forms.ModelForm):
    image_upload = forms.ImageField(required=False, help_text="JPG, PNG, WebP, or AVIF; 5 MB maximum.")

    class Meta:
        model = Product
        fields = "__all__"

    def clean_image_upload(self):
        image = self.cleaned_data.get("image_upload")
        if image and image.size > 5 * 1024 * 1024:
            raise forms.ValidationError("Image must be 5 MB or smaller.")
        return image


class ProductAdmin(admin.ModelAdmin):
    form = ProductAdminForm
    list_display = ("name", "category", "price", "stock", "active", "popularity")
    list_filter = ("category", "active")
    list_editable = ("price", "stock", "active")
    search_fields = ("name", "description")
    ordering = ("name",)
    fieldsets = (
        ("Product", {"fields": ("name", "description", "category", "active")}),
        ("Pricing and stock", {"fields": ("price", "stock", "popularity")}),
        ("Image", {"fields": ("image_upload", "image_url")}),
    )

    def delete_model(self, request, obj):
        obj.active = False
        obj.save(update_fields=("active",))

    def delete_queryset(self, request, queryset):
        queryset.update(active=False)

    def save_model(self, request, obj, form, change):
        image = form.cleaned_data.get("image_upload")
        if image:
            extension = Path(image.name).suffix.lower()
            filename = default_storage.save(f"products/{uuid4().hex}{extension}", ContentFile(image.read()))
            obj.image_url = f"/media/{filename}"
        super().save_model(request, obj, form, change)


class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "total", "payment_method_display", "payment_status", "order_status", "created_at")
    list_filter = ("payment_status", "order_status", "created_at")
    search_fields = ("id", "user__email")
    readonly_fields = (
        "user", "total", "payment_method_display", "payment_status", "created_at",
        "delivery_name", "delivery_phone", "address_line", "city", "state", "postal_code",
    )
    ordering = ("-created_at",)

    @admin.display(description="Payment method")
    def payment_method_display(self, obj):
        payment = Payment.objects.filter(order_id=obj.pk).first()
        return payment.payment_method.upper() if payment else "-"

    def save_model(self, request, obj, form, change):
        previous_status = Order.objects.filter(pk=obj.pk).values_list("order_status", flat=True).first() if change else None
        payment = Payment.objects.filter(order_id=obj.pk).first() if change else None
        collect_cod_payment = bool(payment and payment.payment_method == "cod" and obj.order_status == "delivered")
        if collect_cod_payment:
            obj.payment_status = "paid"
        super().save_model(request, obj, form, change)
        if collect_cod_payment:
            payment.status = "succeeded"
            payment.save(update_fields=("status",))
        if change and previous_status != obj.order_status:
            label = obj.order_status.replace("_", " ").title()
            message = f"Order #{obj.pk} is now {label.lower()}."
            Notification.objects.create(user=obj.user, type="shipping_update", message=message, is_read=False)
            send_email(obj.user.email, message)


class PaymentAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "amount", "payment_method", "status")
    list_filter = ("payment_method", "status")
    search_fields = ("transaction_id",)
    readonly_fields = tuple(field.name for field in Payment._meta.fields)


class CartItemAdmin(admin.ModelAdmin):
    list_display = ("user", "product", "quantity")
    search_fields = ("user__email", "product__name")


class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("order", "product", "quantity", "unit_price")
    readonly_fields = tuple(field.name for field in OrderItem._meta.fields)


class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "type", "is_read", "created_at")
    list_filter = ("type", "is_read")
    search_fields = ("user__email", "message")


admin.site.register(StoreUser, StoreUserAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(Payment, PaymentAdmin)
admin.site.register(CartItem, CartItemAdmin)
admin.site.register(OrderItem, OrderItemAdmin)
admin.site.register(Notification, NotificationAdmin)