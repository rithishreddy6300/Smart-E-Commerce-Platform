from django.apps import AppConfig


class StoreAdminConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "store_admin"
    verbose_name = "Commerce data"

    def ready(self):
        from django.contrib import admin

        from .admin import CartItemAdmin, NotificationAdmin, OrderAdmin, OrderItemAdmin, PaymentAdmin, ProductAdmin, StoreUserAdmin
        from .models import CartItem, Notification, Order, OrderItem, Payment, Product, StoreUser

        registrations = (
            (StoreUser, StoreUserAdmin),
            (Product, ProductAdmin),
            (Order, OrderAdmin),
            (Payment, PaymentAdmin),
            (CartItem, CartItemAdmin),
            (OrderItem, OrderItemAdmin),
            (Notification, NotificationAdmin),
        )
        for model, model_admin in registrations:
            if model not in admin.site._registry:
                admin.site.register(model, model_admin)