from django.db import models
from django.utils import timezone


class StoreUser(models.Model):
    ROLE_CHOICES = [("customer", "Customer"), ("staff", "Staff"), ("admin", "Admin")]

    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=120)
    email = models.EmailField(max_length=255, unique=True)
    password_hash = models.CharField(max_length=255)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        managed = False
        db_table = "store_users"
        ordering = ["-created_at"]

    def __str__(self):
        return self.email


class Product(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=180)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()
    category = models.CharField(max_length=80)
    image_url = models.CharField(max_length=500)
    popularity = models.IntegerField()
    active = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = "store_products"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Order(models.Model):
    STATUS_CHOICES = [
        ("awaiting_payment", "Awaiting payment"),
        ("confirmed", "Confirmed"),
        ("packed", "Packed"),
        ("dispatched", "Dispatched"),
        ("out_for_delivery", "Out for delivery"),
        ("delivered", "Delivered"),
        ("cancelled", "Cancelled"),
    ]
    PAYMENT_CHOICES = [("pending", "Pending"), ("paid", "Paid"), ("failed", "Failed")]

    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(StoreUser, db_column="user_id", on_delete=models.DO_NOTHING, related_name="store_orders")
    total = models.DecimalField(max_digits=10, decimal_places=2)
    payment_status = models.CharField(max_length=30, choices=PAYMENT_CHOICES)
    order_status = models.CharField(max_length=30, choices=STATUS_CHOICES)
    delivery_name = models.CharField(max_length=120, null=True, blank=True)
    delivery_phone = models.CharField(max_length=30, null=True, blank=True)
    address_line = models.CharField(max_length=255, null=True, blank=True)
    city = models.CharField(max_length=100, null=True, blank=True)
    state = models.CharField(max_length=100, null=True, blank=True)
    postal_code = models.CharField(max_length=20, null=True, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = "store_orders"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Order #{self.pk}"


class OrderItem(models.Model):
    id = models.AutoField(primary_key=True)
    order = models.ForeignKey(Order, db_column="order_id", on_delete=models.DO_NOTHING)
    product = models.ForeignKey(Product, db_column="product_id", on_delete=models.DO_NOTHING)
    quantity = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        managed = False
        db_table = "store_order_items"


class Payment(models.Model):
    id = models.AutoField(primary_key=True)
    order = models.ForeignKey(Order, db_column="order_id", on_delete=models.DO_NOTHING)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=40)
    transaction_id = models.CharField(max_length=255)
    status = models.CharField(max_length=30)

    class Meta:
        managed = False
        db_table = "store_payments"


class CartItem(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(StoreUser, db_column="user_id", on_delete=models.DO_NOTHING)
    product = models.ForeignKey(Product, db_column="product_id", on_delete=models.DO_NOTHING)
    quantity = models.IntegerField()

    class Meta:
        managed = False
        db_table = "store_cart_items"


class Notification(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(StoreUser, db_column="user_id", on_delete=models.DO_NOTHING)
    type = models.CharField(max_length=40)
    message = models.CharField(max_length=500)
    is_read = models.BooleanField()
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        managed = False
        db_table = "store_notifications"


