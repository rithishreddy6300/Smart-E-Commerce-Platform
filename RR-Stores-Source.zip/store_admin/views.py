import csv
from io import BytesIO

from django.http import HttpResponse
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

from .models import Order


def sales_csv(request):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="rr-stores-sales.csv"'
    writer = csv.writer(response)
    writer.writerow(("Order", "Customer", "Total (INR)", "Payment status", "Order status", "Created at"))
    for order in Order.objects.select_related("user").order_by("-created_at"):
        writer.writerow((order.pk, order.user.email, order.total, order.payment_status, order.order_status, order.created_at.isoformat()))
    return response


def sales_pdf(request):
    output = BytesIO()
    document = SimpleDocTemplate(output, pagesize=letter, title="RR Stores sales report")
    rows = [["Order", "Customer", "Total (INR)", "Payment", "Status", "Date"]]
    for order in Order.objects.select_related("user").order_by("-created_at"):
        rows.append((str(order.pk), order.user.email, f"INR {order.total:,.2f}", order.payment_status, order.order_status, timezone.localtime(order.created_at).strftime("%Y-%m-%d")))
    table = Table(rows, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f5248")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#d7dfd9")),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f2")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    document.build([table])
    response = HttpResponse(output.getvalue(), content_type="application/pdf")
    response["Content-Disposition"] = 'attachment; filename="rr-stores-sales.pdf"'
    return response