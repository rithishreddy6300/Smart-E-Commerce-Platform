const canvas = document.getElementById('revenue-chart')

if (canvas && window.Chart) {
    const labels = JSON.parse(document.getElementById('revenue-labels').textContent)
    const values = JSON.parse(document.getElementById('revenue-values').textContent)

    new window.Chart(canvas, {
        type: 'bar',
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: '#78a995',
                hoverBackgroundColor: '#245b4f',
                borderRadius: 3,
                maxBarThickness: 34,
            }],
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, border: { display: false } },
                y: {
                    beginAtZero: true,
                    grid: { color: '#e7ece8' },
                    border: { display: false },
                    ticks: { callback: (value) => `INR ${Number(value).toLocaleString('en-IN')}` },
                },
            },
        },
    })
}