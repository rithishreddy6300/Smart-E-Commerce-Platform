from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from store_admin.views import sales_csv, sales_pdf

urlpatterns = [
    path("admin/reports/sales.csv", admin.site.admin_view(sales_csv), name="sales-csv"),
    path("admin/reports/sales.pdf", admin.site.admin_view(sales_pdf), name="sales-pdf"),
    path("admin/", admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)