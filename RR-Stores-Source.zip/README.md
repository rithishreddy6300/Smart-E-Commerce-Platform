# RR Stores

A full-stack commerce starter with an RR Stores React storefront, FastAPI customer API, and Django staff admin. FastAPI and Django share the same SQLite commerce tables; Django's own accounts are used only for staff sign-in.

## What is included

- Customer registration, password login, JWT-protected routes, and optional Auth0 Universal Login for Google/Facebook connections.
- Searchable/filterable catalog, stock-aware cart, saved delivery addresses, order history, shipment tracking, notifications, and a per-customer WebSocket.
- Checkout choices for online payment or cash on delivery. COD is settled when staff marks the order delivered.
- Stripe Checkout and signed webhook handling when Stripe credentials are configured.
- Indian rupee prices throughout the storefront, Stripe checkout, and admin reports.
- A local-only no-charge QR demo when `APP_ENV=development` and Stripe is not configured. A customer explicitly confirms the demo before it marks the order paid; this is not a real payment method.
- Django admin for storefront users/roles, catalog/image uploads, orders/status, payments, carts, and notifications.
- Sales dashboard, top products, low-stock list, and CSV/PDF order exports.
- Alembic schema migration, idempotent demo catalog seeding, API tests, and a Postman collection.

## Requirements

- Python 3.11 or later
- Node.js 20.19+ or 22.12+

## Local setup (Windows PowerShell)

Run commands from the project root unless noted.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Set a unique `JWT_SECRET_KEY` and `DJANGO_SECRET_KEY` in `.env` before sharing the app. Then create the shared schema, sample catalog, and Django staff tables:

```powershell
python -m alembic upgrade head
python -m scripts.seed
python manage.py migrate
python manage.py createsuperuser
```

Install and run the storefront in a separate terminal:

```powershell
cd frontend
npm ci
npm run dev
```

Run the API and admin in two more terminals from the project root:

```powershell
python -m uvicorn api.app.main:app --reload --port 8000
python manage.py runserver 8001
```

Open the storefront at `http://localhost:5173`, API docs at `http://localhost:8000/docs`, and staff admin at `http://localhost:8001/admin/`.

## Configuration

Copy `.env.example` to `.env`. `DATABASE_URL` defaults to `sqlite:///./commerce.sqlite3`; run both Python services from the project root so they resolve the same file. The current Django model mapping is intentionally SQLite-only.

For real Stripe payments, set `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, and `STRIPE_CURRENCY=inr`. Online checkout displays a QR for the hosted Stripe session and also offers a direct link. Configure Stripe to send `checkout.session.completed`, `checkout.session.async_payment_failed`, and `checkout.session.expired` events to `POST /payments/stripe/webhook`. INR must be enabled for your Stripe account. Never use the development demo QR for real transactions.

For social login, create an Auth0 single-page application and API. Set `AUTH0_DOMAIN` and `AUTH0_AUDIENCE` in `.env`, and `VITE_AUTH0_DOMAIN`, `VITE_AUTH0_CLIENT_ID`, and `VITE_AUTH0_AUDIENCE` in `frontend/.env`. Enable Google and Facebook as Auth0 connections and allow the storefront origin as a callback/logout/web origin. Restart Vite after changing frontend environment variables.

For email, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `EMAIL_FROM`. When SMTP is unset, in-app notifications and WebSocket events still work.

New order/shipping notifications are saved in the shared database. The FastAPI WebSocket emits local events immediately and checks the shared notification table every five seconds, so changes made by the separate Django process reach connected customers.

## Useful commands

```powershell
python -m pytest -q
python manage.py check
python -m alembic upgrade head
python -m scripts.seed
cd frontend; npm run lint; npm run build
```

The seed command adds eight sample products only when the catalog is empty. Demo product photography is loaded from Unsplash URLs; uploaded admin images are stored under `media/products/`.

## API and Postman

Import `postman/fieldnotes-commerce.postman_collection.json`. Set `baseUrl` to `http://localhost:8000`; registration/login requests save the returned JWT as the collection's `token` variable. The collection also includes Auth0 exchange, catalog, cart, COD/online checkout, order tracking, notifications, upload, and webhook requests.

Demo captures are in `screenshots/storefront-desktop.png`, `screenshots/storefront-mobile.png`, and `screenshots/checkout-qr-demo.png`.

## Production boundary

This repository is a runnable portfolio/demo foundation, not a production certification. Before a real launch, move the shared database to a production database and update Django's mapping, use managed media storage, add rate limiting/abuse monitoring and transactional outbox delivery, review taxes/shipping/refunds/privacy requirements, and deploy behind TLS with rotated secrets. Verify Stripe webhook retry/idempotency behavior and set `APP_ENV=production`; the API rejects its development JWT secret and disables demo checkout in that mode.