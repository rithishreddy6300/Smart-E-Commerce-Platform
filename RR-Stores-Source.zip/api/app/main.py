import asyncio
import logging
import os
from contextlib import asynccontextmanager
from decimal import Decimal
from pathlib import Path
from uuid import uuid4

from fastapi import Depends, FastAPI, File, HTTPException, Query, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from .database import Base, ROOT_DIR, SessionLocal, engine, get_db
from .models import CartItem, Notification, Order, OrderItem, Payment, Product, StoreUser
from .notifications import manager, notify_user
from .schemas import (
    Auth0Request,
    CartItemInput,
    CartLineView,
    CartQuantityInput,
    CartView,
    CheckoutView,
    CheckoutRequest,
    LoginRequest,
    NotificationView,
    OrderItemView,
    OrderView,
    ProductView,
    TokenView,
    UserCreate,
    UserView,
)
from .security import (
    JWT_ALGORITHM,
    JWT_SECRET,
    create_access_token,
    get_auth0_userinfo,
    get_current_user,
    hash_password,
    require_staff,
    verify_auth0_token,
    verify_password,
)

try:
    import stripe
except ImportError:
    stripe = None

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
NOTIFICATION_POLL_INTERVAL = 5


def initialize_database():
    if os.getenv("APP_ENV", "development") == "production" and JWT_SECRET == "local-development-only-change-this-secret":
        raise RuntimeError("Set JWT_SECRET_KEY before running in production")
    Base.metadata.create_all(bind=engine)


@asynccontextmanager
async def lifespan(_app):
    initialize_database()
    yield


app = FastAPI(title="RR Stores API", version="1.0.0", lifespan=lifespan)
cors_origins = [origin.strip() for origin in os.getenv("API_CORS_ORIGINS", "http://localhost:5173").split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MEDIA_DIR = ROOT_DIR / "media"
PRODUCT_MEDIA_DIR = MEDIA_DIR / "products"
PRODUCT_MEDIA_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/media", StaticFiles(directory=MEDIA_DIR), name="media")


def user_token(user: StoreUser) -> TokenView:
    return TokenView(access_token=create_access_token(user), user=UserView.model_validate(user))


def order_view(order: Order) -> OrderView:
    payment_method = order.payments[0].payment_method if order.payments else "unknown"
    return OrderView(
        id=order.id,
        total=float(order.total),
        payment_status=order.payment_status,
        order_status=order.order_status,
        payment_method=payment_method,
        created_at=order.created_at,
        delivery_name=order.delivery_name,
        delivery_phone=order.delivery_phone,
        address_line=order.address_line,
        city=order.city,
        state=order.state,
        postal_code=order.postal_code,
        items=[
            OrderItemView(
                product_id=item.product_id,
                name=item.product.name,
                quantity=item.quantity,
                unit_price=float(item.unit_price),
            )
            for item in order.items
        ],
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "rr-stores-api"}


@app.post("/auth/register", response_model=TokenView, status_code=201)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    if db.scalar(select(StoreUser).where(StoreUser.email == email)):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = StoreUser(name=payload.name.strip(), email=email, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return user_token(user)


@app.post("/auth/login", response_model=TokenView)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(StoreUser).where(StoreUser.email == str(payload.email).lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Email or password is incorrect")
    return user_token(user)


@app.post("/auth/auth0", response_model=TokenView)
def auth0_login(payload: Auth0Request, db: Session = Depends(get_db)):
    claims = verify_auth0_token(payload.access_token)
    if not claims.get("email"):
        profile = get_auth0_userinfo(payload.access_token)
        if profile.get("sub") != claims.get("sub"):
            raise HTTPException(status_code=401, detail="Auth0 profile does not match the access token")
        claims.update(profile)
    email = claims.get("email", "").lower()
    if not email or claims.get("email_verified") is not True:
        raise HTTPException(status_code=403, detail="A verified email is required")
    user = db.scalar(select(StoreUser).where(StoreUser.email == email))
    if user is None:
        user = StoreUser(name=claims.get("name") or email.split("@", 1)[0], email=email, password_hash="")
        db.add(user)
        db.commit()
        db.refresh(user)
    return user_token(user)


@app.get("/auth/me", response_model=UserView)
def me(user: StoreUser = Depends(get_current_user)):
    return user


@app.get("/products", response_model=list[ProductView])
def list_products(
    category: str | None = None,
    search: str | None = Query(default=None, max_length=100),
    min_price: Decimal | None = Query(default=None, ge=0),
    max_price: Decimal | None = Query(default=None, ge=0),
    sort: str = Query(default="popular", pattern="^(popular|price_asc|price_desc|newest)$"),
    db: Session = Depends(get_db),
):
    query = select(Product).where(Product.active.is_(True))
    if category and category.lower() != "all":
        query = query.where(Product.category == category)
    if search:
        query = query.where(Product.name.ilike(f"%{search}%"))
    if min_price is not None:
        query = query.where(Product.price >= min_price)
    if max_price is not None:
        query = query.where(Product.price <= max_price)
    ordering = {
        "popular": Product.popularity.desc(),
        "price_asc": Product.price.asc(),
        "price_desc": Product.price.desc(),
        "newest": Product.id.desc(),
    }
    return db.scalars(query.order_by(ordering[sort], Product.id)).all()


@app.get("/products/categories", response_model=list[str])
def product_categories(db: Session = Depends(get_db)):
    return db.scalars(select(Product.category).where(Product.active.is_(True)).distinct().order_by(Product.category)).all()


def cart_snapshot(db: Session, user_id: int) -> CartView:
    entries = db.scalars(
        select(CartItem).options(selectinload(CartItem.product)).where(CartItem.user_id == user_id).order_by(CartItem.id)
    ).all()
    items = [
        CartLineView(
            product_id=entry.product_id,
            name=entry.product.name,
            image_url=entry.product.image_url,
            price=float(entry.product.price),
            stock=entry.product.stock,
            quantity=entry.quantity,
            line_total=round(float(entry.product.price) * entry.quantity, 2),
        )
        for entry in entries
    ]
    return CartView(items=items, total=round(sum(item.line_total for item in items), 2))


@app.get("/cart", response_model=CartView)
def get_cart(db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    return cart_snapshot(db, user.id)


@app.post("/cart/items", response_model=CartView)
async def add_cart_item(payload: CartItemInput, db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    product = db.get(Product, payload.product_id)
    if product is None or not product.active:
        raise HTTPException(status_code=404, detail="Product not found")
    existing = db.scalar(select(CartItem).where(CartItem.user_id == user.id, CartItem.product_id == product.id))
    quantity = payload.quantity + (existing.quantity if existing else 0)
    if quantity > product.stock:
        raise HTTPException(status_code=409, detail="Requested quantity exceeds available stock")
    if existing:
        existing.quantity = quantity
    else:
        db.add(CartItem(user_id=user.id, product_id=product.id, quantity=quantity))
    db.commit()
    await manager.publish(user.id, {"type": "cart_updated", "message": "Your cart has been updated"})
    return cart_snapshot(db, user.id)


@app.patch("/cart/items/{product_id}", response_model=CartView)
async def update_cart_item(product_id: int, payload: CartQuantityInput, db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    entry = db.scalar(select(CartItem).where(CartItem.user_id == user.id, CartItem.product_id == product_id))
    if entry is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    if payload.quantity > entry.product.stock:
        raise HTTPException(status_code=409, detail="Requested quantity exceeds available stock")
    entry.quantity = payload.quantity
    db.commit()
    await manager.publish(user.id, {"type": "cart_updated", "message": "Your cart has been updated"})
    return cart_snapshot(db, user.id)


@app.delete("/cart/items/{product_id}", response_model=CartView)
async def remove_cart_item(product_id: int, db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    entry = db.scalar(select(CartItem).where(CartItem.user_id == user.id, CartItem.product_id == product_id))
    if entry is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    db.delete(entry)
    db.commit()
    await manager.publish(user.id, {"type": "cart_updated", "message": "Your cart has been updated"})
    return cart_snapshot(db, user.id)


@app.post("/orders/checkout", response_model=CheckoutView, status_code=201)
async def checkout(
    payload: CheckoutRequest,
    db: Session = Depends(get_db),
    user: StoreUser = Depends(get_current_user),
):
    entries = db.scalars(
        select(CartItem).options(selectinload(CartItem.product)).where(CartItem.user_id == user.id)
    ).all()
    if not entries:
        raise HTTPException(status_code=400, detail="Your cart is empty")
    for entry in entries:
        if not entry.product.active or entry.quantity > entry.product.stock:
            raise HTTPException(status_code=409, detail=f"Insufficient stock for {entry.product.name}")

    total = sum((entry.product.price * entry.quantity for entry in entries), Decimal("0.00"))
    order = Order(
        user_id=user.id,
        total=total,
        payment_status="pending",
        order_status="confirmed" if payload.payment_method == "cod" else "awaiting_payment",
        delivery_name=payload.delivery_name.strip(),
        delivery_phone=payload.delivery_phone.strip(),
        address_line=payload.address_line.strip(),
        city=payload.city.strip(),
        state=payload.state.strip(),
        postal_code=payload.postal_code.strip(),
    )
    db.add(order)
    db.flush()
    payment = Payment(
        order_id=order.id,
        amount=total,
        payment_method="cod" if payload.payment_method == "cod" else "stripe",
        status="pending",
    )
    db.add(payment)
    for entry in entries:
        entry.product.stock -= entry.quantity
        order.items.append(OrderItem(product_id=entry.product_id, quantity=entry.quantity, unit_price=entry.product.price))

    for entry in entries:
        db.delete(entry)

    if payload.payment_method == "cod":
        db.commit()
        await notify_user(
            db,
            user,
            "order_confirmed",
            f"Order #{order.id} is confirmed. Pay ₹{total:,.0f} in cash on delivery.",
        )
        return CheckoutView(
            order_id=order.id,
            total=float(total),
            payment_status="pending",
            order_status=order.order_status,
            payment_method="cod",
        )

    stripe_key = os.getenv("STRIPE_SECRET_KEY", "").strip()
    if not stripe_key:
        if os.getenv("APP_ENV", "development") == "production":
            db.rollback()
            raise HTTPException(status_code=503, detail="Stripe checkout is not configured")
        payment.payment_method = "demo_qr"
        db.commit()
        await manager.publish(user.id, {"type": "order_pending", "message": f"Order #{order.id} is waiting for demo payment"})
        qr_text = f"This is free of cost for using RR Stores. Order #{order.id}. No real payment will be collected in demo mode."
        return CheckoutView(
            order_id=order.id,
            total=float(total),
            payment_status="pending",
            order_status=order.order_status,
            payment_method="demo_qr",
            qr_text=qr_text,
            demo=True,
        )

    if stripe is None:
        db.rollback()
        raise HTTPException(status_code=503, detail="Install the Stripe SDK to enable Stripe checkout")
    try:
        stripe.api_key = stripe_key
        session = stripe.checkout.Session.create(
            mode="payment",
            line_items=[
                {
                    "price_data": {
                        "currency": os.getenv("STRIPE_CURRENCY", "inr"),
                        "unit_amount": int(entry.product.price * 100),
                        "product_data": {"name": entry.product.name},
                    },
                    "quantity": entry.quantity,
                }
                for entry in entries
            ],
            metadata={"order_id": str(order.id), "user_id": str(user.id)},
            success_url=f"{os.getenv('FRONTEND_URL', 'http://localhost:5173')}?checkout=success&order_id={order.id}&session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{os.getenv('FRONTEND_URL', 'http://localhost:5173')}?checkout=cancel&order_id={order.id}",
        )
    except stripe.StripeError as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail="Stripe could not start checkout") from exc

    payment.transaction_id = session.id
    db.commit()
    await manager.publish(user.id, {"type": "order_pending", "message": f"Order #{order.id} is waiting for payment"})
    return CheckoutView(
        order_id=order.id,
        total=float(total),
        payment_status="pending",
        order_status=order.order_status,
        payment_method="stripe",
        checkout_url=session.url,
    )


@app.post("/orders/{order_id}/confirm-demo-payment", response_model=CheckoutView)
async def confirm_demo_payment(
    order_id: int,
    db: Session = Depends(get_db),
    user: StoreUser = Depends(get_current_user),
):
    if os.getenv("APP_ENV", "development") == "production" or os.getenv("STRIPE_SECRET_KEY", "").strip():
        raise HTTPException(status_code=404, detail="Demo payment is not enabled")
    order = db.scalar(
        select(Order)
        .options(selectinload(Order.payments))
        .where(Order.id == order_id, Order.user_id == user.id)
    )
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    payment = order.payments[0] if order.payments else None
    if payment is None or payment.payment_method != "demo_qr" or order.payment_status != "pending":
        raise HTTPException(status_code=409, detail="This order is not awaiting demo payment")
    order.payment_status = "paid"
    order.order_status = "confirmed"
    payment.status = "succeeded"
    db.commit()
    await notify_user(db, user, "order_confirmed", f"Your order is confirmed. Wait for a while; it will reach you.")
    return CheckoutView(
        order_id=order.id,
        total=float(order.total),
        payment_status=order.payment_status,
        order_status=order.order_status,
        payment_method=payment.payment_method,
        demo=True,
    )


@app.post("/payments/stripe/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    secret = os.getenv("STRIPE_WEBHOOK_SECRET", "").strip()
    if not secret or stripe is None:
        raise HTTPException(status_code=503, detail="Stripe webhook is not configured")
    body = await request.body()
    signature = request.headers.get("stripe-signature", "")
    try:
        event = stripe.Webhook.construct_event(body, signature, secret)
    except (ValueError, stripe.SignatureVerificationError) as exc:
        raise HTTPException(status_code=400, detail="Invalid Stripe webhook signature") from exc

    event_type = event["type"]
    if event_type in {"checkout.session.completed", "checkout.session.async_payment_failed", "checkout.session.expired"}:
        session = event["data"]["object"]
        metadata = session.get("metadata") or {}
        order_id = metadata.get("order_id")
        order = db.scalar(select(Order).options(selectinload(Order.items).selectinload(OrderItem.product)).where(Order.id == int(order_id))) if order_id else None
        if order is not None and order.payment_status == "pending":
            payment = db.scalar(select(Payment).where(Payment.order_id == order.id))
            if event_type == "checkout.session.completed" and session.get("payment_status") == "paid":
                order.payment_status = "paid"
                order.order_status = "confirmed"
                payment.status = "succeeded"
                db.commit()
                await notify_user(db, order.user, "order_confirmed", f"Payment received for order #{order.id}. Your order is being prepared.")
            elif event_type in {"checkout.session.async_payment_failed", "checkout.session.expired"}:
                order.payment_status = "failed"
                order.order_status = "cancelled"
                payment.status = "failed"
                for item in order.items:
                    item.product.stock += item.quantity
                db.commit()
                await notify_user(db, order.user, "payment_failed", f"Payment for order #{order.id} was not completed. The items have been returned to stock.")
    return {"received": True}


@app.get("/orders", response_model=list[OrderView])
def list_orders(db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    orders = db.scalars(
        select(Order)
        .options(selectinload(Order.items).selectinload(OrderItem.product), selectinload(Order.payments))
        .where(Order.user_id == user.id)
        .order_by(Order.created_at.desc())
    ).all()
    return [order_view(order) for order in orders]


@app.get("/orders/{order_id}", response_model=OrderView)
def get_order(order_id: int, db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    order = db.scalar(
        select(Order)
        .options(selectinload(Order.items).selectinload(OrderItem.product), selectinload(Order.payments))
        .where(Order.id == order_id, Order.user_id == user.id)
    )
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order_view(order)


@app.get("/notifications", response_model=list[NotificationView])
def list_notifications(db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    return db.scalars(
        select(Notification).where(Notification.user_id == user.id).order_by(Notification.created_at.desc()).limit(50)
    ).all()


@app.post("/notifications/{notification_id}/read", response_model=NotificationView)
def mark_notification_read(notification_id: int, db: Session = Depends(get_db), user: StoreUser = Depends(get_current_user)):
    notification = db.scalar(select(Notification).where(Notification.id == notification_id, Notification.user_id == user.id))
    if notification is None:
        raise HTTPException(status_code=404, detail="Notification not found")
    notification.is_read = True
    db.commit()
    db.refresh(notification)
    return notification


@app.post("/staff/products/{product_id}/image", response_model=ProductView)
async def upload_product_image(
    product_id: int,
    image: UploadFile = File(...),
    db: Session = Depends(get_db),
    _staff: StoreUser = Depends(require_staff),
):
    allowed_types = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/avif": ".avif"}
    extension = allowed_types.get(image.content_type or "")
    if extension is None:
        raise HTTPException(status_code=415, detail="Upload a JPG, PNG, WebP, or AVIF image")
    content = await image.read(5 * 1024 * 1024 + 1)
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image must be 5 MB or smaller")
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    filename = f"{uuid4().hex}{extension}"
    (PRODUCT_MEDIA_DIR / filename).write_bytes(content)
    product.image_url = f"/media/products/{filename}"
    db.commit()
    db.refresh(product)
    return product


@app.websocket("/ws")
async def notifications_socket(websocket: WebSocket, token: str = Query(...)):
    try:
        claims = __import__("jose").jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = int(claims["sub"])
    except Exception:
        await websocket.close(code=4401)
        return
    with SessionLocal() as db:
        cursor = db.scalar(select(func.max(Notification.id)).where(Notification.user_id == user_id)) or 0
    await manager.connect(user_id, websocket, cursor)
    try:
        while True:
            try:
                await asyncio.wait_for(websocket.receive_text(), timeout=NOTIFICATION_POLL_INTERVAL)
            except asyncio.TimeoutError:
                cursor = manager.cursors.get(websocket, cursor)
                with SessionLocal() as db:
                    pending = db.scalars(
                        select(Notification)
                        .where(Notification.user_id == user_id, Notification.id > cursor)
                        .order_by(Notification.id)
                    ).all()
                    updates = [
                        {"type": item.type, "message": item.message, "notification_id": item.id}
                        for item in pending
                    ]
                for update in updates:
                    await manager.publish(user_id, update)
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)