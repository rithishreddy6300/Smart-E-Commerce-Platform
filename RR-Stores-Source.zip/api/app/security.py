import os
import json
import time
from urllib.request import Request, urlopen

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pwdlib import PasswordHash
from sqlalchemy.orm import Session

from .database import get_db
from .models import StoreUser

password_hash = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)
JWT_SECRET = os.getenv("JWT_SECRET_KEY", "local-development-only-change-this-secret")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")


def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    return bool(hashed) and password_hash.verify(password, hashed)


def create_access_token(user: StoreUser) -> str:
    expires = int(time.time()) + int(os.getenv("ACCESS_TOKEN_MINUTES", "60")) * 60
    return jwt.encode({"sub": str(user.id), "role": user.role, "exp": expires}, JWT_SECRET, algorithm=JWT_ALGORITHM)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    db: Session = Depends(get_db),
) -> StoreUser:
    unauthorized = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired access token")
    if credentials is None:
        raise unauthorized
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = int(payload["sub"])
    except (JWTError, KeyError, TypeError, ValueError):
        raise unauthorized
    user = db.get(StoreUser, user_id)
    if user is None:
        raise unauthorized
    return user


def require_staff(user: StoreUser = Depends(get_current_user)) -> StoreUser:
    if user.role not in {"admin", "staff"}:
        raise HTTPException(status_code=403, detail="Staff access required")
    return user


def verify_auth0_token(access_token: str) -> dict:
    domain = os.getenv("AUTH0_DOMAIN", "").strip()
    audience = os.getenv("AUTH0_AUDIENCE", "").strip()
    if not domain or not audience:
        raise HTTPException(status_code=503, detail="Auth0 is not configured")
    issuer = f"https://{domain.rstrip('/')}/"
    try:
        with urlopen(f"{issuer}.well-known/jwks.json", timeout=5) as response:
            jwks = json.loads(response.read())
        header = jwt.get_unverified_header(access_token)
        key = next(key for key in jwks["keys"] if key["kid"] == header["kid"])
        return jwt.decode(access_token, key, algorithms=["RS256"], audience=audience, issuer=issuer)
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Auth0 token could not be verified") from exc


def get_auth0_userinfo(access_token: str) -> dict:
    domain = os.getenv("AUTH0_DOMAIN", "").strip()
    request = Request(
        f"https://{domain.rstrip('/')}/userinfo",
        headers={"Authorization": f"Bearer {access_token}"},
    )
    try:
        with urlopen(request, timeout=5) as response:
            return json.loads(response.read())
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Auth0 profile could not be verified") from exc