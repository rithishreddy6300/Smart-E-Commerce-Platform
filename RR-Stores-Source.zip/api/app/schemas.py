from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserView(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str

    model_config = ConfigDict(from_attributes=True)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class Auth0Request(BaseModel):
    access_token: str


class TokenView(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserView


class ProductView(BaseModel):
    id: int
    name: str
    description: str
    price: float
    stock: int
    category: str
    image_url: str
    popularity: int
    active: bool

    model_config = ConfigDict(from_attributes=True)


class CartItemInput(BaseModel):
    product_id: int
    quantity: int = Field(default=1, ge=1, le=20)


class CartQuantityInput(BaseModel):
    quantity: int = Field(ge=1, le=20)


class CartLineView(BaseModel):
    product_id: int
    name: str
    image_url: str
    price: float
    stock: int
    quantity: int
    line_total: float


class CartView(BaseModel):
    items: list[CartLineView]
    total: float


class OrderItemView(BaseModel):
    product_id: int
    name: str
    quantity: int
    unit_price: float


class OrderView(BaseModel):
    id: int
    total: float
    payment_status: str
    order_status: str
    payment_method: str
    created_at: datetime
    delivery_name: str | None = None
    delivery_phone: str | None = None
    address_line: str | None = None
    city: str | None = None
    state: str | None = None
    postal_code: str | None = None
    items: list[OrderItemView]


class CheckoutRequest(BaseModel):
    payment_method: str = Field(pattern="^(online|cod)$")
    delivery_name: str = Field(min_length=1, max_length=120)
    delivery_phone: str = Field(min_length=7, max_length=30)
    address_line: str = Field(min_length=5, max_length=255)
    city: str = Field(min_length=1, max_length=100)
    state: str = Field(min_length=1, max_length=100)
    postal_code: str = Field(min_length=4, max_length=20)


class CheckoutView(BaseModel):
    order_id: int
    total: float
    payment_status: str
    order_status: str
    payment_method: str
    checkout_url: str | None = None
    qr_text: str | None = None
    demo: bool = False


class NotificationView(BaseModel):
    id: int
    type: str
    message: str
    is_read: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)