import logging
import os
import smtplib
from email.message import EmailMessage

from fastapi import WebSocket
from sqlalchemy.orm import Session

from .models import Notification, StoreUser

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self):
        self.connections: dict[int, set[WebSocket]] = {}
        self.cursors: dict[WebSocket, int] = {}

    async def connect(self, user_id: int, websocket: WebSocket, last_notification_id: int):
        await websocket.accept()
        self.connections.setdefault(user_id, set()).add(websocket)
        self.cursors[websocket] = last_notification_id

    def disconnect(self, user_id: int, websocket: WebSocket):
        self.connections.get(user_id, set()).discard(websocket)
        self.cursors.pop(websocket, None)

    async def publish(self, user_id: int, payload: dict):
        for websocket in tuple(self.connections.get(user_id, set())):
            try:
                notification_id = payload.get("notification_id")
                if notification_id and notification_id <= self.cursors.get(websocket, 0):
                    continue
                await websocket.send_json(payload)
                if notification_id:
                    self.cursors[websocket] = notification_id
            except Exception:
                self.disconnect(user_id, websocket)


manager = ConnectionManager()


async def notify_user(db: Session, user: StoreUser, event_type: str, message: str):
    notification = Notification(user_id=user.id, type=event_type, message=message)
    db.add(notification)
    db.commit()
    await manager.publish(user.id, {"type": event_type, "message": message, "notification_id": notification.id})
    send_email(user.email, message)


def send_email(recipient: str, message: str):
    host = os.getenv("SMTP_HOST", "").strip()
    sender = os.getenv("EMAIL_FROM", "").strip()
    if not host or not sender:
        return
    email = EmailMessage()
    email["Subject"] = "Order update from RR Stores"
    email["From"] = sender
    email["To"] = recipient
    email.set_content(message)
    try:
        with smtplib.SMTP(host, int(os.getenv("SMTP_PORT", "587")), timeout=10) as smtp:
            smtp.starttls()
            username = os.getenv("SMTP_USER", "")
            if username:
                smtp.login(username, os.getenv("SMTP_PASSWORD", ""))
            smtp.send_message(email)
    except Exception:
        logger.exception("Could not send notification email")